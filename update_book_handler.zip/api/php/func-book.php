<?php
// Function to get all books
function get_all_books($conn) {
    $stmt = $conn->prepare("SELECT * FROM books");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to get a book by ID
function get_book_by_id($conn, $book_id) {
    $stmt = $conn->prepare("SELECT * FROM books WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function get_book($conn, $id) {
    $stmt = $conn->prepare("SELECT * FROM books WHERE book_id = ?");
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        return $stmt->fetch();
    } else {
        return null;
    }
}

// Function to create a new book
function create_book($conn, $title, $author_id, $description, $genre, $cover, $file) {
    $stmt = $conn->prepare("INSERT INTO books (title, author_id, description, genre, cover, file) VALUES (:title, :author_id, :description, :genre, :cover, :file)");
    $stmt->bindParam(':title', $title);
    $stmt->bindParam(':author_id', $author_id);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':genre', $genre);
    $stmt->bindParam(':cover', $cover);
    $stmt->bindParam(':file', $file);
    return $stmt->execute();
}

// Function to update a book
function update_book($conn, $book_id, $title, $author_id, $description, $genre, $cover, $file) {
    $stmt = $conn->prepare("UPDATE books SET title = :title, author_id = :author_id, description = :description, genre = :genre, cover = :cover, file = :file WHERE book_id = :book_id");
    $stmt->bindParam(':title', $title);
    $stmt->bindParam(':author_id', $author_id);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':genre', $genre);
    $stmt->bindParam(':cover', $cover);
    $stmt->bindParam(':file', $file);
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Function to delete a book
function delete_book($conn, $book_id) {
    $stmt = $conn->prepare("DELETE FROM books WHERE book_id = :book_id");
    $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
    return $stmt->execute();
}

// Search books function
function search_books($conn, $key) {
    $key = "%{$key}%";
    $stmt = $conn->prepare("SELECT * FROM books WHERE title LIKE ? OR description LIKE ?");
    $stmt->execute([$key, $key]);

    if ($stmt->rowCount() > 0) {
        return $stmt->fetchAll();
    } else {
        return [];
    }
}

// Get books by category
function get_books_by_category($conn, $id) {
    $stmt = $conn->prepare("SELECT * FROM books WHERE category_id = ?");
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        return $stmt->fetchAll();
    } else {
        return [];
    }
}

// Get books by author
function get_books_by_author($conn, $id) {
    $stmt = $conn->prepare("SELECT * FROM books WHERE author_id = ?");
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        return $stmt->fetchAll();
    } else {
        return [];
    }
}
?>
