<?php
function get_all_orders($conn) {
    $sql = "SELECT orders.order_id, orders.customer_id, orders.book_id, orders.order_date, orders.quantity, orders.total_price, books.title, books.price, customers.name AS customer_name
            FROM orders
            INNER JOIN books ON orders.book_id = books.book_id
            INNER JOIN customers ON orders.customer_id = customers.customer_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $orders = $stmt->fetchAll();
    } else {
        $orders = 0;
    }
    return $orders;
}
