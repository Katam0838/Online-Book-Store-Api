<?php
session_start();

# If the admin is not logged in, redirect to login page
if (!isset($_SESSION['user_id']) && !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

# Database Connection File
include "../db_conn.php";

# Check if the customer ID is provided
if (!isset($_GET['id'])) {
    header("Location: ../admin.php");
    exit;
}

$customer_id = $_GET['id'];

# Delete the customer from the database
$stmt = $conn->prepare("DELETE FROM customers WHERE customer_id = :customer_id");
$stmt->bindParam(':customer_id', $customer_id, PDO::PARAM_INT);
if ($stmt->execute()) {
    $success = "Customer deleted successfully!";
} else {
    $error = "Failed to delete customer!";
}

header("Location: ../admin.php");
exit;
?>

<!-- Back Arrow -->
<a href="admin.php" class="d-block my-3">
    <img src="img/back-arrow.PNG" alt="Back" width="30">
</a>
