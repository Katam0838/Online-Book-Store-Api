<?php
session_start();
if (isset($_SESSION['user_id']) && isset($_SESSION['user_email'])) {
    include "db_connect.php";
    include "php/func-book.php";
    include "php/func-author.php";

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $title = $_POST['title'];
        $author_id = $_POST['author_id'];
        $description = $_POST['description'];
        $genre = $_POST['genre'];
        $cover = $_FILES['cover']['name'];
        $file = $_FILES['file']['name'];

        move_uploaded_file($_FILES['cover']['tmp_name'], "uploads/cover/" . $cover);
        move_uploaded_file($_FILES['file']['tmp_name'], "uploads/file/" . $file);

        if (create_book($conn, $title, $author_id, $description, $genre, $cover, $file)) {
            header("Location: admin.php");
        } else {
            echo "Error creating book.";
        }
    }

    $authors = get_all_authors($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1>Add Book</h1>
    <form action="create_book.php" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="mb-3">
            <label for="author" class="form-label">Author</label>
            <select class="form-control" id="author" name="author_id" required>
                <?php foreach ($authors as $author) { ?>
                    <option value="<?=$author['author_id']?>"><?=$author['name']?></option>
                <?php } ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" required></textarea>
        </div>
        <div class="mb-3">
            <label for="genre" class="form-label">Genre</label>
            <input type="text" class="form-control" id="genre" name="genre" required>
        </div>
        <div class="mb-3">
            <label for="cover" class="form-label">Cover</label>
            <input type="file" class="form-control" id="cover" name="cover" required>
        </div>
        <div class="mb-3">
            <label for="file" class="form-label">File</label>
            <input type="file" class="form-control" id="file" name="file" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Book</button>
    </form>
</div>
</body>
</html>
<?php } else {
    header("Location: login.php");
    exit;
}
?>
