<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Check if book_id is provided in the URL
if (isset($_GET['book_id'])) {
    include "db_conn.php"; // Include database connection
    $id = $_GET['book_id']; // Get book_id from URL parameters

    // Prepare and execute DELETE statement
    $stmt = $conn->prepare("DELETE FROM books WHERE book_id = ?");
    $stmt->execute([$id]);
}

// Redirect to admin page
header("Location: ../admin.php");
exit;
?>
