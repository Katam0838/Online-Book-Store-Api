<?php
require_once __DIR__ . '/db_conn.php';
require_once __DIR__ . '/gen_token.php'; 

function authenticate() {
    // Get headers
    $headers = apache_request_headers();

    if (isset($headers['Authorization'])) {
        $matches = [];
        if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
            $jwt = $matches[1];
            try {
                $decoded = JWT::decode($jwt, '12345', array('HS256'));
                return $decoded;
            } catch (Exception $e) {
                http_response_code(401);
                echo json_encode(["message" => "Unauthorized: Invalid token"]);
                exit;
            }
        } else {
            http_response_code(401);
            echo json_encode(["message" => "Unauthorized: Token not found"]);
            exit;
        }
    } else {
        http_response_code(401);
        echo json_encode(["message" => "Unauthorized: No Authorization header"]);
        exit;
    }
}
?>
