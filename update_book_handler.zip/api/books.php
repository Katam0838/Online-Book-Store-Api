<?php
require_once __DIR__ . '/../php/db_conn.php';
require_once __DIR__ . '/../php/func-auth.php';

// Authenticate request
authenticate();

$request_method = $_SERVER["REQUEST_METHOD"];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

switch($request_method) {
    case 'GET':
        if ($id) {
            get_book($id);
        } else {
            get_books();
        }
        break;
    case 'POST':
        add_book();
        break;
    case 'PUT':
        if ($id) {
            update_book($id);
        } else {
            http_response_code(400);
            echo json_encode(["message" => "Bad Request: ID is required"]);
        }
        break;
    case 'DELETE':
        if ($id) {
            delete_book($id);
        } else {
            http_response_code(400);
            echo json_encode(["message" => "Bad Request: ID is required"]);
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(["message" => "Method Not Allowed"]);
        break;
}

function get_books() {
    global $conn;
    $query = "SELECT * FROM books";
    $result = $conn->query($query);
    $books = $result->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($books);
}

function get_book($id) {
    global $conn;
    $query = "SELECT * FROM books WHERE book_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$id]);
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($book) {
        echo json_encode($book);
    } else {
        http_response_code(404);
        echo json_encode(["message" => "Book not found"]);
    }
}

function add_book() {
    global $conn;
    $data = json_decode(file_get_contents("php://input"), true);
    if (isset($data['title'], $data['author_id'], $data['genre'], $data['price'], $data['stock_quantity'])) {
        $query = "INSERT INTO books (title, author_id, genre, price, stock_quantity) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([$data['title'], $data['author_id'], $data['genre'], $data['price'], $data['stock_quantity']]);
        http_response_code(201);
        echo json_encode(["message" => "Book added successfully"]);
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Bad Request: Missing required fields"]);
    }
}

function update_book($id) {
    global $conn;
    $data = json_decode(file_get_contents("php://input"), true);
    if (isset($data['title'], $data['author_id'], $data['genre'], $data['price'], $data['stock_quantity'])) {
        $query = "UPDATE books SET title = ?, author_id = ?, genre = ?, price = ?, stock_quantity = ? WHERE book_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$data['title'], $data['author_id'], $data['genre'], $data['price'], $data['stock_quantity'], $id]);
        echo json_encode(["message" => "Book updated successfully"]);
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Bad Request: Missing required fields"]);
    }
}

function delete_book($id) {
    global $conn;
    $query = "DELETE FROM books WHERE book_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$id]);
    echo json_encode(["message" => "Book deleted successfully"]);
}
?>