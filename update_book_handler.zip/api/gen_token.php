<?php
use \Firebase\JWT\JWT; // Make sure to include the JWT library

function generate_token($id) {
    $key = "12345"; // Replace with your secret key
    $payload = [
        "user_id" => $id,
        "exp" => time() + (60 * 60) // Token expiration time (1 hour from now)
    ];

    return JWT::encode($payload, $key);
}
?>
