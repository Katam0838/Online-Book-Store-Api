<?php
require_once '../php/db_conn.php';
require_once '../php/func-auth.php';

// Authenticate request
authenticate();

$request_method = $_SERVER["REQUEST_METHOD"];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

switch($request_method) {
    case 'GET':
        if ($id) {
            get_author($id);
        } else {
            get_authors();
        }
        break;
    case 'POST':
        add_author();
        break;
    case 'PUT':
        if ($id) {
            update_author($id);
        } else {
            http_response_code(400);
            echo json_encode(["message" => "Bad Request: ID is required"]);
        }
        break;
    case 'DELETE':
        if ($id) {
            delete_author($id);
        } else {
            http_response_code(400);
            echo json_encode(["message" => "Bad Request: ID is required"]);
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(["message" => "Method Not Allowed"]);
        break;
}

function get_authors() {
    global $conn;
    $query = "SELECT * FROM authors";
    $result = $conn->query($query);
    $authors = $result->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($authors);
}

function get_author($id) {
    global $conn;
    $query = "SELECT * FROM authors WHERE author_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$id]);
    $author = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($author) {
        echo json_encode($author);
    } else {
        http_response_code(404);
        echo json_encode(["message" => "Author not found"]);
    }
}

function add_author() {
    global $conn;
    $data = json_decode(file_get_contents("php://input"), true);
    if (isset($data['name'], $data['bio'])) {
        $query = "INSERT INTO authors (name, bio) VALUES (?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->execute([$data['name'], $data['bio']]);
        http_response_code(201);
        echo json_encode(["message" => "Author added successfully"]);
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Bad Request: Missing required fields"]);
    }
}

function update_author($id) {
    global $conn;
    $data = json_decode(file_get_contents("php://input"), true);
    if (isset($data['name'], $data['bio'])) {
        $query = "UPDATE authors SET name = ?, bio = ? WHERE author_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$data['name'], $data['bio'], $id]);
        echo json_encode(["message" => "Author updated successfully"]);
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Bad Request: Missing required fields"]);
    }
}

function delete_author($id) {
    global $conn;
    $query = "DELETE FROM authors WHERE author_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$id]);
    echo json_encode(["message" => "Author deleted successfully"]);
}
?>
